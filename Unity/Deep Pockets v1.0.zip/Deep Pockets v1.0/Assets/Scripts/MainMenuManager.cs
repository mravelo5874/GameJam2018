﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuManager : MonoBehaviour {

    public GameObject Game;
    public GameObject GameManager;
    public Camera cam;
    public GameObject DungeonCreator;
    public CanvasGroup canvasGroup;
    public CanvasGroup HowToPlayCanvasGroup;
    public GameObject store;
    public bool UIopen;
    public bool HowToPlayUIopen;

    void Start()
    {
        UIopen = true;
        HowToPlayUIopen = false;
    }

    public void ToggleHowToPlayCanvas()
    {
        if (HowToPlayUIopen)
        {
            HowToPlayUIopen = false;
        }
        else
        {
            HowToPlayUIopen = true;
        }
    }

    public void NewRun()
    {
        RunGame();
        GameManager.GetComponent<GameManager>().NewGame();
    }

    void OnLevelWasLoaded()
    {
        UIopen = false;
    }

    void RunGame()
    {
        UIopen = false;
        cam.enabled = false;
        DungeonCreator.SetActive(true);
        GameManager.SetActive(true);
        store.SetActive(true);
        Game.SetActive(true);
    }

    public void ReturnToMenu()
    {
        UIopen = true;
        cam.enabled = true;
        DungeonCreator.SetActive(false);
        GameManager.SetActive(false);
        store.SetActive(false);
        Game.SetActive(false);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    void Update()
    {
        if (UIopen)
        {
            canvasGroup.alpha = 1f;
            canvasGroup.blocksRaycasts = true;
        }
        else
        {
            canvasGroup.alpha = 0f;
            canvasGroup.blocksRaycasts = false;
        }

        if (HowToPlayUIopen)
        {
            HowToPlayCanvasGroup.alpha = 1f;
            HowToPlayCanvasGroup.blocksRaycasts = true;
        }
        else
        {
            HowToPlayCanvasGroup.alpha = 0f;
            HowToPlayCanvasGroup.blocksRaycasts = false;
        }
    }
}
