﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class LoadDungeonScreen : MonoBehaviour
{

    public void LoadStore()
    {
        SceneManager.LoadScene("Dungeon_1", LoadSceneMode.Single);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            LoadStore();
        }
    }
}