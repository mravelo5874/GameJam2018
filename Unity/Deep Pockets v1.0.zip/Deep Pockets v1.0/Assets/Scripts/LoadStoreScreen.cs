﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class LoadStoreScreen : MonoBehaviour {

    public void LoadStore()
    {
        GameObject.Find("StorePoint").GetComponent<PlayerStartPoint>().movePlayer();
        GameObject.Find("SpawnEnemies").GetComponent<SpawnEnemies>().DeleteAllEnemies();
        GameObject.Find("StoreScreen").GetComponent<ShopManager>().UIopen = true;
        GameObject.Find("MainCamera").GetComponent<CameraController>().SetStoreBounds();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            LoadStore();
        }
    }
}
