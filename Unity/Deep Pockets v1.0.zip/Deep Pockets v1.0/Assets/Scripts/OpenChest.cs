﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenChest : MonoBehaviour {

    public Sprite openChestSprite;
    private SpriteRenderer renderer;

    private GameObject ItemIndex;

    private bool isOpen;

    private void Start()
    {
        isOpen = false;
        renderer = GetComponentInParent<SpriteRenderer>();
        ItemIndex = GameObject.Find("ItemIndexObject");
    }

    private GameObject randomItem()
    {
        return ItemIndex.GetComponent<ItemIndex>().RandomChestItem();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!isOpen)
        {
            if (other.CompareTag("Player"))
            {
                renderer.sprite = openChestSprite;
                isOpen = true;

                Vector2 itemPos = new Vector2(transform.position.x + Random.Range(-1.5f, 1.5f), transform.position.y + 0.5f);
                GameObject item = randomItem();
                Instantiate(item, itemPos, Quaternion.identity);
                
            }
        }
    }
}
