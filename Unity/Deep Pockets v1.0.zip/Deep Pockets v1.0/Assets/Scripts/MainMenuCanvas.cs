﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuCanvas : MonoBehaviour {

    public static MainMenuCanvas MM;

    void Awake()
    {
        DontDestroy();
    }

    void DontDestroy()
    {
        if (MM == null)
        {
            DontDestroyOnLoad(gameObject);
            MM = this;
        }
        else
        {
            if (MM != this)
            {
                Destroy(gameObject);
            }
        }
    }
}
