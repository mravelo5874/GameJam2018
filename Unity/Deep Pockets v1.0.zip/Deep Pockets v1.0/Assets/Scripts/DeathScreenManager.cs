﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class DeathScreenManager : MonoBehaviour {

    public TextMeshProUGUI FloorsText;
    public TextMeshProUGUI GoldText;
    public TextMeshProUGUI EnemiesText;

    public GameObject LevelData;

    public bool UIopen;
    public CanvasGroup canvasGroup;

    void Awake()
    {
        UIopen = false;
    }

    void Update () {
        if (UIopen)
        {
            canvasGroup.alpha = 1f;
            canvasGroup.blocksRaycasts = true;
        }
        else
        {
            canvasGroup.alpha = 0f;
            canvasGroup.blocksRaycasts = false;
        }

        FloorsText.text = "Floors Traversed: " + LevelData.GetComponent<LevelCounter>().ReturnLevel();
        GoldText.text = "Gold Collected: "+ LevelData.GetComponent<LevelCounter>().goldCount;
        EnemiesText.text = "Enemies Slain: "+ LevelData.GetComponent<LevelCounter>().enemiesCount;
    }

    public void ResetGame()
    {
        GameObject.Find("StoreScreen").GetComponent<ShopManager>().UIopen = false;
        GameObject.Find("GameManager").GetComponent<GameManager>().ResetGame();
        GameObject.Find("MainMenu").GetComponent<MainMenuManager>().ReturnToMenu();
    }
}
