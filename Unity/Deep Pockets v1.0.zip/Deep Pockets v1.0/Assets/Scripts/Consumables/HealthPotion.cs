﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPotion : MonoBehaviour {

    public int amountToHeal;

    public void Heal()
    {
        GameObject GM = GameObject.Find("Player");
        GM.GetComponent<PlayerHealthManager>().Heal(amountToHeal);
        Destroy(gameObject);
    }
}
