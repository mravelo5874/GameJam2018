﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class LoadNewArea : MonoBehaviour {

	public string levelToLoad;
    //private GameObject player;

	// Use this for initialization
	void Start () {
        //player = GameObject.Find("GameManager");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D(Collider2D other) {

		if(other.gameObject.name == "Player") {
            
            Scene sceneToLoad = SceneManager.GetSceneByName(levelToLoad);

            SceneManager.LoadScene(sceneToLoad.name, LoadSceneMode.Single);
            //SceneManager.MoveGameObjectToScene(player.gameObject, sceneToLoad);
		}
	}
}
