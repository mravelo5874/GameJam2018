﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public static GameManager GM;

    void Awake()
    {
        MakeThisTheOnlyGameManager();
        inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<Inventory>();
    }

    public void OnNewFloor()
    {
        GameObject.Find("LevelData").GetComponent<LevelCounter>().IncreaseLevelCount();
        GameObject.Find("DungeonCreator").GetComponent<DungeonGenerator>().NewGame();
        GameObject.Find("SpawnEnemies").GetComponent<SpawnEnemies>().Spawn();
        GameObject.Find("StartPoint").GetComponent<PlayerStartPoint>().movePlayer();
    }

    void MakeThisTheOnlyGameManager()
    {
        if (GM == null)
        {
            DontDestroyOnLoad(gameObject);
            GM = this;
        }
        else
        {
            if (GM != this)
            {
                Destroy(gameObject);
            }
        }
    }

    public int goldAmount;

    public int MaxWeight;
    public int CurrWeight;
    public int PlayerHealth;

    public float playerSpeed;
    public float normSpeed;
    public float slowSpeed;

    private Inventory inventory;
    public int MAX_Weight;
    public float MAX_Speed;
    public int MAX_Health;

    private int default_start_gold;
    private int default_start_health;
    private int default_start_weight;
    private float default_start_speed;

    public GameObject OnPlayerDeathScreen;

    void Start () {
        
	}

    public void NewGame()
    {
        OnNewFloor();
        default_start_gold = goldAmount;
        default_start_health = PlayerHealth;
        default_start_weight = MaxWeight;
        default_start_speed = normSpeed;
        playerSpeed = normSpeed;
    }

    public void ResetGame()
    {
        GameObject.Find("DungeonCreator").GetComponent<DungeonGenerator>().DeleteDungeon();
        GameObject.Find("LevelData").GetComponent<LevelCounter>().Reset();
        GameObject.Find("SpawnEnemies").GetComponent<SpawnEnemies>().DeleteAllEnemies();
        clearInventory();
        PlayerHealth = default_start_health;
        GameObject.Find("Player").GetComponent<PlayerHealthManager>().playerCurrHealth = PlayerHealth;
        MaxWeight = default_start_weight;
        normSpeed = default_start_speed;
        goldAmount = default_start_gold;


        OnPlayerDeathScreen.GetComponent<DeathScreenManager>().UIopen = false;
        GameObject.Find("Player").GetComponent<PlayerHealthManager>().isDead = false;
    }

    public void clearInventory()
    {
        for (int i = 0; i < inventory.slots.Length; i++)
        {
            if (inventory.isFull[i] == true)
            {
                if (inventory.slots[i].transform.childCount > 0)
                    inventory.slots[i].transform.GetChild(0).GetComponent<SellItem>().Sell();
            }
        }
        goldAmount = 0;
    }

    public int CalculateNumberEnemies()
    {
        var level = GameObject.Find("LevelData").GetComponent<LevelCounter>().ReturnLevel();

        return 25 + (3 * level);
    }

    public int CalculateEnemyDamage()
    {
        var level = GameObject.Find("LevelData").GetComponent<LevelCounter>().ReturnLevel();

        return 6 + (2 * level);
    }

    public int CalculateEnemyHealth()
    {
        var level = GameObject.Find("LevelData").GetComponent<LevelCounter>().ReturnLevel();

        return 10 + (2 * level);
    }

    public void DeathScreen()
    {
        OnPlayerDeathScreen.GetComponent<DeathScreenManager>().UIopen = true;
    }

    public float HealthPercent()
    {
        return ((float)PlayerHealth - default_start_health) / (MAX_Health - default_start_health);
    }

    public float WeightPercent()
    {
        return ((float)MaxWeight - default_start_weight) / (MAX_Weight - default_start_weight);
    }

    public float SpeedPercent()
    {
        return ((float)normSpeed - default_start_speed )/ (MAX_Speed - default_start_speed);
    }

    public void AddGold(int amount)
    {
        goldAmount += amount;
        GameObject.Find("LevelData").GetComponent<LevelCounter>().IncreaseGoldCount(amount);
    }

    public void RemoveGold(int amount)
    {
        goldAmount -= amount;
        if (goldAmount <= 0)
            goldAmount = 0;
    }

    public void IncreaseHealth(int amount)
    {
        PlayerHealth += amount;
        GameObject.Find("Player").GetComponent<PlayerHealthManager>().Heal(amount);
        if (PlayerHealth >= MAX_Health)
            PlayerHealth = MAX_Health;
    }

    public void IncreaseStrength(int amount)
    {
        MaxWeight += amount;
        if (MaxWeight >= MAX_Weight)
            MaxWeight = MAX_Weight;
    }

    public void IncreaseSpeed(int amount)
    {
        normSpeed += amount;
        if (normSpeed >= MAX_Speed)
            normSpeed = MAX_Speed;
    }

    // Update is called once per frame
    void Update () {
        CurrWeight = 0;

        for (int i = 0; i < inventory.slots.Length; i++)
        {
            if (inventory.isFull[i] == true)
            {
                if (inventory.slots[i].transform.childCount > 0)
                    CurrWeight += inventory.slots[i].transform.GetChild(0).GetComponent<ItemData>().weight;
            }
        }

        if (CurrWeight > MaxWeight)
        {
            playerSpeed = slowSpeed;
        }
        else
        {
            playerSpeed = normSpeed;
        }
    }
}
