﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelCounter : MonoBehaviour {

    public int LevelCount;
    public int goldCount;
    public int enemiesCount;

    public int HealthCost;
    public int StrengthCost;
    public int SpeedCost;

    private int goldStart;

    public void Reset()
    {
        HealthCost = 10;
        StrengthCost = 10;
        SpeedCost = 10;
        LevelCount = 0;
        enemiesCount = 0;
        goldCount = goldStart;
    }

    public void IncreaseLevelCount()
    {
        LevelCount++;
    }

    public int ReturnLevel()
    {
        //Debug.Log(LevelCount / 2);
        return LevelCount / 2;
    }

    void OnLevelWasLoaded()
    {
    }

    private void Start()
    {
        goldStart = goldCount;
        Reset();
    }

    public void IncreaseGoldCount(int amount)
    {
        goldCount += amount;
    }

    public void IncreaseEnemyCount(int amount)
    {
        enemiesCount += amount;
    }

    public void IncreaseHealthCost(int amount)
    {
        HealthCost += amount;
    }

    public void IncreaseStrengthCost(int amount)
    {
        StrengthCost += amount;
    }

    public void IncreaseSpeedCost(int amount)
    {
        SpeedCost += amount;
    }

}
