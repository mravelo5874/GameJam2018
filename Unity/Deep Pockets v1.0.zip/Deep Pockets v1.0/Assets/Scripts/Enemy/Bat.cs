﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bat : MonoBehaviour {

    private bool playerInRadius;
    public GameObject healthManager;
    private Animator anim;
    public float speed;

    public float knockBack_time;
    public bool isKnockBack;
    public float knockBack_speed;
    private float knockBack_timer;

    public Vector2 lastMove;
    private float curr_speed;

    public void KnockBack()
    {
        knockBack_timer = knockBack_time;
        curr_speed = -knockBack_speed;
        isKnockBack = true;
    }

    private void Start()
    {
        curr_speed = speed;
        anim = GetComponent<Animator>();
        isKnockBack = false;
        playerInRadius = false;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            //Debug.Log("Player in!");
            playerInRadius = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            //Debug.Log("Player out!");
            playerInRadius = false;
        }
    }


    private void Update()
    {
        GameObject player = GameObject.Find("Player");
        if (player.GetComponent<PlayerHealthManager>().isDead)
        {
            Destroy(gameObject);
        }

        if (isKnockBack)
        {
            knockBack_timer -= Time.deltaTime;
            if (knockBack_timer <= 0f)
            {
                //Debug.Log("timer up!");
                isKnockBack = false;
                curr_speed = speed;
            }


        }

        if (playerInRadius && !healthManager.GetComponent<EnemyHealthManager>().isDead && !player.GetComponent<PlayerHealthManager>().isDead)
        {
            float step = curr_speed * Time.deltaTime;

            transform.position = Vector3.MoveTowards(transform.position, player.transform.position, step);
            if (player.transform.position.x > transform.position.x)
                anim.SetBool("isRight", true);
            else anim.SetBool("isRight", false);

            lastMove = new Vector2(transform.position.x, transform.position.y);
        }
    }
}
