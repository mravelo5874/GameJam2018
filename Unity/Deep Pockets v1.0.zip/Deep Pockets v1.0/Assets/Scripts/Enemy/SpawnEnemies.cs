﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEnemies : MonoBehaviour {

    public List<GameObject> enemies = new List<GameObject>();
    public int List_size;

    private int[,] map;

    private int width;
    private int height;

    private int number_of_enemies;
    public GameObject EnemyPrefab;
    public GameObject startPos;

    void Start()
    {
        map = GameObject.Find("DungeonCreator").GetComponent<DungeonGenerator>().map;
        width = GameObject.Find("DungeonCreator").GetComponent<DungeonGenerator>().width;
        height = GameObject.Find("DungeonCreator").GetComponent<DungeonGenerator>().height;
        //Spawn();
    }

    public void Spawn()
    {
        number_of_enemies = GameObject.Find("GameManager").GetComponent<GameManager>().CalculateNumberEnemies();

        for (int i = 0; i < number_of_enemies; i++)
        {
            int x = Random.Range(0, map.GetUpperBound(0));
            int y = Random.Range(0, map.GetUpperBound(1));

            GameObject enemy = (GameObject)Instantiate(EnemyPrefab);
            enemies.Add(enemy);
            List_size++;
            enemy.transform.position = new Vector3Int(-x + width / 2, -y + height / 2, 0);
        }
    }

    public void DeleteAllEnemies()
    {
        for (int i = 0; i < List_size; i++)
        {
            Destroy(enemies[i]);
        }
        enemies.Clear();
        List_size = 0;
    }

}
