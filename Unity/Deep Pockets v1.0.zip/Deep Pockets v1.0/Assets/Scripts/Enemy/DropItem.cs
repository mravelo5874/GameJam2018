﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropItem : MonoBehaviour {

    private GameObject itemIndex;

    void Start()
    {
        itemIndex = GameObject.Find("ItemIndexObject");
    }

    public void DropRandomItem()
    {
        var item = itemIndex.GetComponent<ItemIndex>().RandomItem();
        Vector2 pos = new Vector2(transform.position.x, transform.position.y - 1);
        Instantiate(item, pos, Quaternion.identity);
    }

}
