﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GoldWeightText : MonoBehaviour
{

    public TextMeshProUGUI WeightText;
    public TextMeshProUGUI GoldText;
    private int goldAmount;
    private int MaxWeight;
    private int CurrWeight;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        goldAmount = gameObject.GetComponent<GameManager>().goldAmount;
        MaxWeight = gameObject.GetComponent<GameManager>().MaxWeight;
        CurrWeight = gameObject.GetComponent<GameManager>().CurrWeight;

        var GoldString = "Gold: " + goldAmount.ToString();
        var WeightString = "Weight: " + CurrWeight.ToString() + "\\" + MaxWeight.ToString();

        GoldText.text = GoldString;
        WeightText.text = WeightString;
    }
}
