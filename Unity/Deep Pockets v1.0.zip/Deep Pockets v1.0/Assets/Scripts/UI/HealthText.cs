﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class HealthText : MonoBehaviour {

    public TextMeshProUGUI myText;
    public GameObject player;
    private int MaxHealth;
    private int CurrHealth;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        MaxHealth = player.GetComponent<PlayerHealthManager>().playerMaxHealth;
        CurrHealth = player.GetComponent<PlayerHealthManager>().playerCurrHealth;

        var displayString = CurrHealth.ToString() + "/" + MaxHealth.ToString();

        myText.text = displayString;

    }
}
