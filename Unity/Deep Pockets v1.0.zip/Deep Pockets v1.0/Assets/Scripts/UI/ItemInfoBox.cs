﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ItemInfoBox : MonoBehaviour {

    public bool isOpen;
    public CanvasGroup itemInfoBox;
    public TextMeshProUGUI myText;
    public string stringToShow;

    public void UpdateText(int value, int weight, string description)
    {
        stringToShow = "Value: " + value.ToString() + "\nWeight: " + weight.ToString() + "\n\n" + description;
    }

    public void ToggleBox()
    {
        if (isOpen)
        {
            isOpen = false;
        }
        else if (!isOpen)
        {
            isOpen = true;
        }
    }

    // Use this for initialization
    void Start () {
        itemInfoBox = gameObject.GetComponent<CanvasGroup>();
        isOpen = false;
    }

    // Update is called once per frame
    void Update () {
        if (isOpen)
        {
            itemInfoBox.alpha = 1f;
            itemInfoBox.blocksRaycasts = true;
        }
        else
        {
            itemInfoBox.alpha = 0f;
            itemInfoBox.blocksRaycasts = false;
        }

        myText.text = stringToShow;
    }
}
