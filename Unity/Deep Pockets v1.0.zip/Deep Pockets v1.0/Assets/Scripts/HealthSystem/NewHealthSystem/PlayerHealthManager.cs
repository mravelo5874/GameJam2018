﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealthManager : MonoBehaviour {

    public Transform healthBar;
    public int playerMaxHealth;
    public int playerCurrHealth;

    public float time_invulnerable;
    public bool isInvulnerable;
    public float inv_timer;

    public float time_attacking;
    public bool isAttacking;
    public float attack_timer;

    private Color resetColor;
    private Color AttackColor;
    private Color invulnerableColor;
    private SpriteRenderer rend;

    public bool isDead;

    private void SetColors()
    {
        resetColor.g = rend.color.g;
        resetColor.r = rend.color.r;
        resetColor.b = rend.color.b;
        resetColor.a = rend.color.a;

        invulnerableColor.g = 0.3f;
        invulnerableColor.r = 0.5f;
        invulnerableColor.b = 0.8f;
        invulnerableColor.a = 0.8f;

        AttackColor.r = 0.87f;
        AttackColor.g = 0.64f;
        AttackColor.b = 0.1f;
        AttackColor.a = 1f;
    }

    private void Start()
    {
        rend = GetComponent<SpriteRenderer>();
        SetColors();
        playerMaxHealth = GameObject.Find("GameManager").GetComponent<GameManager>().PlayerHealth;
        isInvulnerable = false;
        isDead = false;
        isAttacking = false;
        playerCurrHealth = playerMaxHealth;
    }

    private void Update()
    {
        playerMaxHealth = GameObject.Find("GameManager").GetComponent<GameManager>().PlayerHealth;

        if (isInvulnerable)
        {
            inv_timer -= Time.deltaTime;
            if (inv_timer <= 0f)
            {
                isInvulnerable = false;
                rend.material.color = resetColor;
            }   
        }

        if(isAttacking)
        {
            attack_timer -= Time.deltaTime;
            if (attack_timer <= 0f)
            {
                isAttacking = false;
                rend.material.color = resetColor;
            }
        }

        healthBar.localScale = new Vector3(1, (float)playerCurrHealth / playerMaxHealth, 1);

        if (playerCurrHealth <= 0)
        {
            GameObject.Find("GameManager").GetComponent<GameManager>().DeathScreen();
            isDead = true;
        }
    }

    public void Damage(int num)
    {
        if (!isInvulnerable)
        {
            playerCurrHealth -= num;

            if (playerCurrHealth < 0)
            {
                playerCurrHealth = 0;
            }
        }
    }

    public void Heal(int num)
    {
        playerCurrHealth += num;

        if (playerCurrHealth > playerMaxHealth)
        {
            playerCurrHealth = playerMaxHealth;
        }
    }

    public void Invulnerable()
    {
        if (!isInvulnerable)
        {
            rend.material.color = invulnerableColor;
            inv_timer = time_invulnerable;
            isInvulnerable = true;
            GetComponent<PlayerMovement>().KnockBack();
        }
    }

    public void AttackColorChange()
    {
        if (!isAttacking)
        {
            rend.material.color = AttackColor;
            attack_timer = time_attacking;
            isAttacking = true;
        }
    }
}
