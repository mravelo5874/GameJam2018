﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HurtEnemy : MonoBehaviour {

    public int CoinDamage;
    public int NoCoinDamage;
    public int swingCost;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            if (GameObject.Find("GameManager").GetComponent<GameManager>().goldAmount >= swingCost)
            {
                other.gameObject.GetComponent<EnemyHealthManager>().Damage(CoinDamage);
                GameObject.Find("Player").GetComponent<PlayerHealthManager>().AttackColorChange();
            }
            else
            {
                other.gameObject.GetComponent<EnemyHealthManager>().Damage(NoCoinDamage);
            }
            other.gameObject.transform.parent.GetComponent<Bat>().KnockBack();
            other.gameObject.GetComponent<EnemyHealthManager>().Invulnerable();
            GameObject.Find("GameManager").GetComponent<GameManager>().RemoveGold(swingCost);
        }
    }
}
