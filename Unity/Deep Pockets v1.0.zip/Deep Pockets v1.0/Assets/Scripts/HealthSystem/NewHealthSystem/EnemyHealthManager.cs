﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealthManager : MonoBehaviour {

    public Transform healthBar;
    private int enemyMaxHealth;
    public int enemyCurrHealth;

    public float time_invulnerable;
    private bool isInvulnerable;
    private float inv_timer;

    public Animator anim;
    public bool isDead;
    private Color resetColor;
    private Color invulnerableColor;
    private SpriteRenderer rend;

    private void SetColors()
    {
        resetColor.g = rend.color.g;
        resetColor.r = rend.color.r;
        resetColor.b = rend.color.b;
        resetColor.a = rend.color.a;

        invulnerableColor.g = 0.3f;
        invulnerableColor.r = 0.8f;
        invulnerableColor.b = 0.3f;
        invulnerableColor.a = 0.8f;
    }

    private void Start()
    {
        rend = GetComponentInParent<SpriteRenderer>();
        SetColors();
        isInvulnerable = false;
        isDead = false;
        enemyMaxHealth = GameObject.Find("GameManager").GetComponent<GameManager>().CalculateEnemyHealth();
        enemyCurrHealth = enemyMaxHealth;
    }

    private void Update()
    {
        if (isInvulnerable)
        {
            inv_timer -= Time.deltaTime;
            if (inv_timer <= 0f)
            {
                isInvulnerable = false;
                rend.material.color = resetColor;
            }
        }

        if (!isDead)
            healthBar.localScale = new Vector3((float)enemyCurrHealth / enemyMaxHealth, 1, 1);

        if (enemyCurrHealth <= 0)
        {
            anim.SetBool("isDead", true);
            Destroy();
        }
    }

    public void Destroy()
    {
        if (!isDead)
        {
            GetComponent<CircleCollider2D>().gameObject.SetActive(false);
            Destroy(healthBar.transform.parent.gameObject);
            Destroy(transform.parent.gameObject, 1);

            isDead = true;
            gameObject.GetComponent<DropItem>().DropRandomItem();
            GameObject.Find("LevelData").GetComponent<LevelCounter>().IncreaseEnemyCount(1);
        }
    }

    public void Damage(int num)
    {
        if (!isInvulnerable && !isDead)
        {
            enemyCurrHealth -= num;

            if (enemyCurrHealth < 0)
            {
                enemyCurrHealth = 0;
            }
        }
    }

    public void Heal(int num)
    {
        enemyCurrHealth += num;

        if (enemyCurrHealth > enemyMaxHealth)
        {
            enemyCurrHealth = enemyMaxHealth;
        }
    }

    public void Invulnerable()
    {
        if (!isInvulnerable)
        {
            rend.material.color = invulnerableColor;
            inv_timer = time_invulnerable;
            isInvulnerable = true;
        }
    }
}
