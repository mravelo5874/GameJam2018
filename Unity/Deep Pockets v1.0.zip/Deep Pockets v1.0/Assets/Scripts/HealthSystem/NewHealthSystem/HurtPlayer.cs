﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HurtPlayer : MonoBehaviour {

    private int damage;

	void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            damage = GameObject.Find("GameManager").GetComponent<GameManager>().CalculateEnemyDamage();

            other.gameObject.GetComponent<PlayerHealthManager>().Damage(damage);
            gameObject.transform.parent.GetComponent<Bat>().KnockBack();
            other.gameObject.GetComponent<PlayerHealthManager>().Invulnerable();
        }
    }
}
