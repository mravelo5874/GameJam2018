﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.Tilemaps;
using System.Collections.Generic;

public class DungeonGenerator : MonoBehaviour
{
    public GameObject playerStart;
    public GameObject exit;
    private GameObject exit_location;
    public GameObject chestPrefab;
    private GameObject chest;

    public List<GameObject> blocks = new List<GameObject>();
    public int List_size;

    private GameObject bounds;

    // wall tiles:
    public GameObject bedrock;
    public GameObject wall_main;
    public GameObject wall_1;
    public GameObject wall_2;
    public GameObject wall_3;
    public GameObject wall_4;
    public GameObject wall_5;
    public GameObject wall_6;
    public GameObject wall_7;
    public GameObject wall_8;

    public GameObject wall_free;
    public GameObject wall_n;
    public GameObject wall_s;
    public GameObject wall_e;
    public GameObject wall_w;
    public GameObject wall_ne;
    public GameObject wall_nw;
    public GameObject wall_se;
    public GameObject wall_sw;
    public GameObject wall_nwe;
    public GameObject wall_wns;
    public GameObject wall_swe;
    public GameObject wall_ens;
    public GameObject wall_ew_corr;
    public GameObject wall_ns_corr;


    // ground tiles:
    public GameObject ground_main;
    public GameObject ground_1;
    public GameObject ground_2;
    public GameObject ground_3;
    public GameObject ground_4;
    public GameObject ground_5;

    [Range(50, 200)]
    public int height;

    [Range(50, 200)]
    public int width;

    public int[,] map;

    [Range(1, 50)]
    public int rooms;

    [Range(2, 10)]
    public int MaxRoomSize;

    [Range(2, 10)]
    public int MinRoomSize;

    [Range(1, 10)]
    public int MaxCorrSize;

    [Range(1, 10)]
    public int MinCorrSize;

    void Awake()
    {
        List_size = 0;
        map = GenerateArray(width, height, false);
    }

    public void NewGame()
    {
        if (List_size > 0)
        {
            DeleteDungeon();
        }

        //bounds = GameObject.Find("GameBounds");
        //bounds.transform.localScale = new Vector3(width - 1, height - 1, 0f);
        //bounds.transform.position += new Vector3(1f, 1f, 0f);

        GenerateDungeon();
        draw();
    }

    void OnLevelWasLoaded()
    {
        NewGame();
    }

    public void DeleteDungeon()
    {
        for(int i = 0; i < List_size; i++)
        {
            Destroy(blocks[i]);
        }
        blocks.Clear();
        Destroy(exit_location);
        Destroy(chest);
        List_size = 0;
    }

    private GameObject choose_ground()
    {
        int num = Random.Range(0, 100);

        if (num <= 95)
        {
            return ground_main;
        }
        else if (num > 95 && num <= 100)
        {
            int num2 = Random.Range(0, 5);

            switch (num2)
            {
                case 0:
                    {
                        return ground_1;
                        break;
                    }
                case 1:
                    {
                        return ground_2;
                        break;
                    }
                case 2:
                    {
                        return ground_3;
                        break;
                    }
                case 3:
                    {
                        return ground_4;
                        break;
                    }
                case 4:
                    {
                        return ground_5;
                        break;
                    }
                default:
                    {
                        return ground_main;
                        break;
                    }
            }
        }
        // if nothing get returned:
        return ground_main;
    }

    private GameObject choose_wall_main()
    {
        int num = Random.Range(0, 1000);

        if (num <= 990)
        {
            return wall_main;
        }
        else if (num > 990 && num <= 1000)
        {
            int num2 = Random.Range(0, 8);

            switch (num2)
            {
                case 0:
                    {
                        return wall_1;
                        break;
                    }
                case 1:
                    {
                        return wall_2;
                        break;
                    }
                case 2:
                    {
                        return wall_3;
                        break;
                    }
                case 3:
                    {
                        return wall_4;
                        break;
                    }
                case 4:
                    {
                        return wall_5;
                        break;
                    }
                case 5:
                    {
                        return wall_6;
                        break;
                    }
                case 6:
                    {
                        return wall_7;
                        break;
                    }
                case 7:
                    {
                        return wall_8;
                        break;
                    }
                default:
                    {
                        return wall_main;
                        break;
                    }
            }
        }
        // if nothing get returned:
        return wall_main;
    }

    private GameObject choose_wall(int north, int south, int east, int west)
    {
        if (north == 1 && south == 1 && east == 1 && west == 1) // surrounded by blocks
        {
            return choose_wall_main();
        }
        if (north == 0 && south == 0 && east == 0 && west == 0) // free
        {
            return wall_free;
        }
        else if (north == 0 && south == 1 && east == 1 && west == 1) // open north
        {
            return wall_n;
        }
        else if (north == 1 && south == 0 && east == 1 && west == 1) // open south
        {
            return wall_s;
        }
        else if (north == 1 && south == 1 && east == 0 && west == 1) // open east
        {
            return wall_e;
        }
        else if (north == 1 && south == 1 && east == 1 && west == 0) // open west
        {
            return wall_w;
        }
        else if (north == 1 && south == 0 && east == 0 && west == 1) // open south east
        {
            return wall_se;
        }
        else if (north == 0 && south == 1 && east == 0 && west == 1) // open north east
        {
            return wall_ne;
        }
        else if (north == 0 && south == 1 && east == 1 && west == 0) // open north west
        {
            return wall_nw;
        }
        else if (north == 1 && south == 0 && east == 1 && west == 0) // open south west
        {
            return wall_sw;
        }
        else if (north == 0 && south == 1 && east == 0 && west == 0) // open north west east
        {
            return wall_nwe;
        }
        else if (north == 0 && south == 0 && east == 1 && west == 0) // open north west south
        {
            return wall_wns;
        }
        else if (north == 1 && south == 0 && east == 0 && west == 0) // open south east west
        {
            return wall_swe;
        }
        else if (north == 0 && south == 0 && east == 0 && west == 1) // open north south east
        {
            return wall_ens;
        }
        else if (north == 1 && south == 1 && east == 0 && west == 0) // east west corridor
        {
            return wall_ew_corr;
        }
        else if (north == 0 && south == 0 && east == 1 && west == 1) // north south corridor
        {
            return wall_ns_corr;
        }
        return wall_main;
    }

    private struct values
    {
        public int topLx;
        public int topLy;
        public int botRx;
        public int botRy;

        public values (int a, int b, int c, int d)
        {
            topLx = a;
            topLy = b;
            botRx = c;
            botRy = d;
        }
    };

    private void create_room(values val)
    {
        for (int i = val.topLy; i < val.botRy; i++)
        {
            for (int j = val.topLx; j < val.botRx; j++)
            {
                map[i, j] = 0;
            }
        }
    }

    private values northCorridor(values val, int new_len, int new_hght, int entry_offset, int corr_length)
    {
        int X = Random.Range(val.topLx, val.botRx - 1);
        int startY = val.topLy;

        // if room is out of bounds
        if (X - entry_offset <= 0 || startY - corr_length - new_hght <= 0 || X - entry_offset + new_len >= width - 1 || startY - corr_length >= height - 1)
        {
            return create_corridor(val);
        }

        // draw corridor
        for (int i = 0; i < corr_length + MinRoomSize; i++)
        {
            map[startY - i - 1, X] = 0;
            map[startY - i - 1, X + 1] = 0;
        }

        return new values(X - entry_offset, startY - corr_length - new_hght, X - entry_offset + new_len, startY - corr_length);
    }

    private values southCorridor(values val, int new_len, int new_hght, int entry_offset, int corr_length)
    {
        int X = Random.Range(val.topLx, val.botRx - 1);
        int startY = val.botRy;

        // if room is out of bounds
        if (X - entry_offset <= 0 || startY + corr_length <= 0 || X - entry_offset + new_len >= width - 1 || startY + corr_length + new_hght >= height - 1)
        {
            return create_corridor(val);
        }

        // draw corridor
        for (int i = 0; i < corr_length + MinRoomSize; i++)
        {
            map[startY + i, X] = 0;
            map[startY + i, X + 1] = 0;
        }

        return new values(X - entry_offset, startY + corr_length, X - entry_offset + new_len, startY + corr_length + new_hght);
    }

    private values eastCorridor(values val, int new_len, int new_hght, int entry_offset, int corr_length)
    {
        int Y = Random.Range(val.topLy, val.botRy - 1);
        int startX = val.botRx;

        // if room is out of bounds
        if (startX + corr_length <= 0 || Y + entry_offset - new_hght <= 0 || startX + corr_length + new_len >= width - 1 || Y + entry_offset >= height - 1)
        {
            return create_corridor(val);
        }

        // draw corridor
        for (int i = 0; i < corr_length + MinRoomSize; i++)
        {
            map[Y, startX + i] = 0;
            map[Y + 1, startX + i] = 0;
        }

        return new values(startX + corr_length, Y + entry_offset - new_hght, startX + corr_length + new_len, Y + entry_offset);
    }

    private values westCorridor(values val, int new_len, int new_hght, int entry_offset, int corr_length)
    {
        int Y = Random.Range(val.topLy, val.botRy - 1);
        int startX = val.topLx;

        // if room is out of bounds
        if (startX - corr_length - new_len <= 0 || Y + entry_offset - new_hght <= 0 || startX - corr_length >= width - 1 || Y + entry_offset >= height - 1)
        {
            return create_corridor(val);
        }

        // draw corridor
        for (int i = 0; i < corr_length + MinRoomSize; i++)
        {
            map[Y, startX - i - 1] = 0;
            map[Y + 1, startX - i - 1] = 0;
        }

        return new values(startX - corr_length - new_len, Y + entry_offset - new_hght, startX - corr_length, Y + entry_offset);
    }

    private values create_corridor(values val)
    {
        int dir = Random.Range(0, 4);
        values new_val = new values();

        // generate new coords for next room
        int new_len = Random.Range(MinRoomSize, MaxRoomSize);
        int new_hght = Random.Range(MinRoomSize, MaxRoomSize);
        int entry_offset = Random.Range(0, new_len);
        int corr_length = Random.Range(MinCorrSize, MaxCorrSize);

        switch (dir)
        {
            case 0:
                { // north
                  //cout << "north" << endl;
                    new_val = northCorridor(val, new_len, new_hght, entry_offset, corr_length);
                    break;
                }
            case 1:
                { // east
                  //cout << "east" << endl;
                    new_val = eastCorridor(val, new_len, new_hght, entry_offset, corr_length);
                    break;
                }
            case 2:
                { // south
                  //cout << "south" << endl;
                    new_val = southCorridor(val, new_len, new_hght, entry_offset, corr_length);
                    break;
                }
            case 3:
                { // west
                  //cout << "west" << endl;
                    new_val = westCorridor(val, new_len, new_hght, entry_offset, corr_length);
                    break;
                }
        }
        return new_val;
    }

    private void GenerateDungeon()
    {
        resetArray();
        int a = width / 2 - Random.Range(MinRoomSize, MaxRoomSize);
        int b = height / 2 - Random.Range(MinRoomSize, MaxRoomSize);
        int offset = Random.Range(MinRoomSize, MaxRoomSize);
        values val = new values( a, b, a + offset, b + offset );

        // place player in the middle of the first room
        int x = b + (offset / 2);
        int y = a + (offset / 2);
        playerStart.transform.position = new Vector3Int(-x + width / 2 + 1, -y + height / 2 + 1, 0);
        playerStart.GetComponent<PlayerStartPoint>().movePlayer();

        for (int i = 0; i < rooms; i++)
        {
            create_room(val);
            if (i != rooms - 1)
                val = create_corridor(val);
        }

        exit_location = (GameObject)Instantiate(exit);
        int y_exit = (val.topLx + val.botRx) / 2;
        int x_exit = (val.botRy + val.topLy) / 2;
        exit_location.transform.position = new Vector3Int(-x_exit + width / 2 + 1, -y_exit + height / 2 + 1, 0);

        chest = (GameObject)Instantiate(chestPrefab);
        chest.transform.position = new Vector3Int(-x_exit + width / 2 + 1, -y_exit + height / 2 + (MinRoomSize / 2), 0);
    }

    public void draw()
    {
        for (int x = 0; x < map.GetUpperBound(0); x++)
        {
            for (int y = 0; y < map.GetUpperBound(1); y++)
            {
                float x_location = -x + width / 2;
                float y_location = -y + height / 2;

                if (map[x, y] == 0)
                {
                    GameObject ground_tile = (GameObject)Instantiate(choose_ground());
                    blocks.Add(ground_tile);
                    List_size++;
                    ground_tile.transform.position = new Vector3(x_location, y_location, 0f);
                }
                else if (x == 0 || x == map.GetUpperBound(0) - 1 || y == 0 || y == map.GetUpperBound(1) - 1)
                {
                    GameObject bedrock_tile = (GameObject)Instantiate(bedrock);
                    blocks.Add(bedrock_tile);
                    List_size++;
                    bedrock_tile.transform.position = new Vector3(x_location, y_location, 0f);
                }
                else
                {
                    int north = map[x, y - 1];
                    int south = map[x, y + 1];
                    int east = map[x - 1, y];
                    int west = map[x + 1, y];

                    GameObject wall_tile = (GameObject)Instantiate(choose_wall(north, south, east, west));
                    blocks.Add(wall_tile);
                    List_size++;
                    wall_tile.transform.position = new Vector3(x_location, y_location, 0f);
                }
            }
        }
    }

    private static int[,] GenerateArray(int width, int height, bool empty)
    {

        int[,] map = new int[width, height];
        for (int x = 0; x < map.GetUpperBound(0); x++)
        {
            for (int y = 0; y < map.GetUpperBound(1); y++)
            {
                if (empty)
                {
                    map[x, y] = 0;
                }
                else
                {
                    map[x, y] = 1;
                }
            }
        }

        return map;
    }

    public void resetArray()
    {
        for (int x = 0; x < map.GetUpperBound(0); x++)
        {
            for (int y = 0; y < map.GetUpperBound(1); y++)
            {
                map[x, y] = 1;
            }
        }
    }
}