﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemIndex : MonoBehaviour {

    public int number_of_items;
    public int number_chest_items;

    public GameObject item_1;
    public GameObject item_2;
    public GameObject item_3;
    public GameObject item_4;
    public GameObject item_5;

    public GameObject item_6;
    public GameObject item_7;
    public GameObject item_8;
    public GameObject item_9;
    public GameObject item_10;

    public GameObject item_11;
    public GameObject item_12;
    public GameObject item_13;
    public GameObject item_14;
    public GameObject item_15;

    public GameObject item_16;
    public GameObject item_17;
    public GameObject item_18;
    public GameObject item_19;
    public GameObject item_20;

    public GameObject chest_item_1;
    public GameObject chest_item_2;
    public GameObject chest_item_3;
    public GameObject chest_item_4;
    public GameObject chest_item_5;

    public GameObject RandomChestItem()
    {
        int num = Random.Range(1, number_chest_items + 1);

        switch (num)
        {
            case 1: { return chest_item_1; break; }
            case 2: { return chest_item_2; break; }
            case 3: { return chest_item_3; break; }
            case 4: { return chest_item_4; break; }
            case 5: { return chest_item_5; break; }
            default: { return item_1; break; }
        }
    }

    public GameObject RandomItem()
    {
        int num = Random.Range(1, number_of_items + 1);

        switch (num)
        {
            case 1: { return item_1; break; }
            case 2: { return item_2; break; }
            case 3: { return item_3; break; }
            case 4: { return item_4; break; }
            case 5: { return item_5; break; }

            case 6: { return item_6; break; } 
            case 7: { return item_7; break; }
            case 8: { return item_8; break; }
            case 9: { return item_9; break; }
            case 10: { return item_10; break; }

            case 11: { return item_11; break; }
            case 12: { return item_12; break; }
            case 13: { return item_13; break; }
            case 14: { return item_14; break; }
            case 15: { return item_15; break; }

            case 16: { return item_16; break; }
            case 17: { return item_17; break; }
            case 18: { return item_18; break; }
            case 19: { return item_19; break; }
            case 20: { return item_20; break; }
            default: { return item_1; break; }
        }
    }
}
