﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUp : MonoBehaviour
{

    private Inventory inventory;
    public GameObject itemButton;

    public float time_before_pickup;
    private bool isPickup;

    private void Start()
    {
        StartCoroutine(DelayPickup());
        inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<Inventory>();
    }

    IEnumerator DelayPickup()
    {
        isPickup = false;
        yield return new WaitForSeconds(time_before_pickup);
        isPickup = true;
    }

    private void Update()
    {

    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (isPickup)
        {
            if (other.CompareTag("Player"))
            {
                for (int i = 0; i < inventory.slots.Length; i++)
                {
                    if (inventory.isFull[i] == false)
                    {
                        // item can be added to inventory
                        inventory.isFull[i] = true;
                        Instantiate(itemButton, inventory.slots[i].transform, false);
                        Destroy(gameObject);

                        break;
                    }
                }
            }
        }
    }
}

