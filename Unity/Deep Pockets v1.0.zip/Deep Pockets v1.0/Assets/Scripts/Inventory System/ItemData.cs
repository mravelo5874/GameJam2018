﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemData : MonoBehaviour {

    public int value;
    public int weight;
    public string description;
    private GameObject itemBox;


	void Start () {
        itemBox = GameObject.Find("ItemInfoBox");
	}

    public void ToggleBox()
    {
        itemBox.GetComponent<ItemInfoBox>().ToggleBox();
    }

    public void UpdateText()
    {
        itemBox.GetComponent<ItemInfoBox>().UpdateText(value, weight, description);
    }
}
