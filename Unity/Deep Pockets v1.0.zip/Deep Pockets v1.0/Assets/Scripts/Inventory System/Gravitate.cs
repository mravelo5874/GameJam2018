﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gravitate : MonoBehaviour
{

    private Transform player;
    public float item_speed;
    public float item_drop_lag;
    private Inventory inventory;


    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<Inventory>();
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if ( item_drop_lag < 0f)
        {
            if (other.CompareTag("Player"))
            {
                for (int i = 0; i < inventory.slots.Length; i++)
                {
                    if (inventory.isFull[i] == false)
                    {
                        Vector2 playerPos = new Vector2(player.position.x, player.position.y);

                        if (gameObject.transform.position.x > playerPos.x)
                        {
                            transform.parent.Translate(Vector2.left * item_speed * Time.deltaTime);
                        }
                        else if (gameObject.transform.position.x < playerPos.x)
                        {
                            transform.parent.Translate(Vector2.right * item_speed * Time.deltaTime);
                        }

                        if (gameObject.transform.position.y > playerPos.y)
                        {
                            transform.parent.Translate(Vector2.down * item_speed * Time.deltaTime);
                        }
                        else if (gameObject.transform.position.y < playerPos.y)
                        {
                            transform.parent.Translate(Vector2.up * item_speed * Time.deltaTime);
                        }
                    }
                }
            }
        }
    }

    private void Update()
    {
        if (item_drop_lag >= 0f)
            item_drop_lag -= Time.deltaTime;
    }

}
