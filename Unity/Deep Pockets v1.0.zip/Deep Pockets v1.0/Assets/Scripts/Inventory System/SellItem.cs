﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SellItem : MonoBehaviour {

	public void Sell()
    {
        var value = gameObject.GetComponent<ItemData>().value;
        GameObject.Find("GameManager").GetComponent<GameManager>().AddGold(value);
        Destroy(gameObject);
    }
}
