﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ShopManager : MonoBehaviour {

    public GameObject Button_1;
    public GameObject Button_2;
    public GameObject Button_3;

    public GameObject Slider_1;
    public GameObject Slider_2;
    public GameObject Slider_3;

    public TextMeshProUGUI HealthDisplayText;
    public TextMeshProUGUI HealthCostText;

    public TextMeshProUGUI StrengthDisplayText;
    public TextMeshProUGUI StrengthCostText;

    public TextMeshProUGUI SpeedDisplayText;
    public TextMeshProUGUI SpeedCostText;

    private GameObject playerManager;
    private static int HealthCost;
    private static int StrengthCost;
    private static int SpeedCost;

    public bool UIopen;
    public CanvasGroup canvasGroup;

    private void Start()
    {
        UIopen = false;
        playerManager = GameObject.Find("GameManager");
        HealthCost = GameObject.Find("LevelData").GetComponent<LevelCounter>().HealthCost;
        StrengthCost = GameObject.Find("LevelData").GetComponent<LevelCounter>().StrengthCost;
        SpeedCost = GameObject.Find("LevelData").GetComponent<LevelCounter>().SpeedCost;
    }

    private void Update()
    {
        if (UIopen)
        {
            canvasGroup.alpha = 1f;
            canvasGroup.blocksRaycasts = true;
        }
        else
        {
            canvasGroup.alpha = 0f;
            canvasGroup.blocksRaycasts = false;
        }

        Slider_1.transform.localScale = new Vector3(1, playerManager.GetComponent<GameManager>().HealthPercent(), 1);
        Slider_2.transform.localScale = new Vector3(1, playerManager.GetComponent<GameManager>().WeightPercent(), 1);
        Slider_3.transform.localScale = new Vector3(1, playerManager.GetComponent<GameManager>().SpeedPercent(), 1);

        var healthString = playerManager.GetComponent<GameManager>().PlayerHealth + "\\" + playerManager.GetComponent<GameManager>().MAX_Health;
        HealthDisplayText.text = healthString;

        var strengthString = playerManager.GetComponent<GameManager>().MaxWeight + "\\" + playerManager.GetComponent<GameManager>().MAX_Weight;
        StrengthDisplayText.text = strengthString;

        var speedString = playerManager.GetComponent<GameManager>().normSpeed + "\\" + playerManager.GetComponent<GameManager>().MAX_Speed;
        SpeedDisplayText.text = speedString;

        HealthCost = GameObject.Find("LevelData").GetComponent<LevelCounter>().HealthCost;
        StrengthCost = GameObject.Find("LevelData").GetComponent<LevelCounter>().StrengthCost;
        SpeedCost = GameObject.Find("LevelData").GetComponent<LevelCounter>().SpeedCost;

        HealthCostText.text = "Cost: " + HealthCost;
        StrengthCostText.text = "Cost: " + StrengthCost;
        SpeedCostText.text = "Cost: " + SpeedCost;
    }

    public void UpgradeHealth()
    {
        if (playerManager.GetComponent<GameManager>().goldAmount >= HealthCost)
        {
            playerManager.GetComponent<GameManager>().RemoveGold(HealthCost);
            playerManager.GetComponent<GameManager>().IncreaseHealth(2);
            GameObject.Find("LevelData").GetComponent<LevelCounter>().IncreaseHealthCost(10);
        }
    }

    public void UpgradeWeight()
    {
        if (playerManager.GetComponent<GameManager>().goldAmount >= StrengthCost)
        {
            playerManager.GetComponent<GameManager>().RemoveGold(StrengthCost);
            playerManager.GetComponent<GameManager>().IncreaseStrength(2);
            GameObject.Find("LevelData").GetComponent<LevelCounter>().IncreaseStrengthCost(10);
        }
    }

    public void UpgradeSpeed()
    {
        if (playerManager.GetComponent<GameManager>().goldAmount >= SpeedCost)
        {
            playerManager.GetComponent<GameManager>().RemoveGold(SpeedCost);
            playerManager.GetComponent<GameManager>().IncreaseSpeed(10);
            GameObject.Find("LevelData").GetComponent<LevelCounter>().IncreaseSpeedCost(10);
        }
    }

}
