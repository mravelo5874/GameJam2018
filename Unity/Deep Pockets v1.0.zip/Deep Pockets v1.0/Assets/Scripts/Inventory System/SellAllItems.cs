﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SellAllItems : MonoBehaviour
{

    private Inventory inventory;

    void Start()
    {
        inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<Inventory>();
    }

    public void SellAll()
    {
        for (int i = 0; i < inventory.slots.Length; i++)
        {
            if (inventory.isFull[i] == true)
            {
                if (inventory.slots[i].transform.childCount > 0)
                    inventory.slots[i].transform.GetChild(0).GetComponent<SellItem>().Sell();
            }
        }
    }
}
