﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour {

    public bool[] isFull;
    public GameObject[] slots;

	public void clear()
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (isFull[i] == true)
            {
                if (slots[i].transform.childCount > 0)
                {
                    foreach (Transform child in transform)
                        Destroy(child.gameObject);
                }
                    
            }
        }
    }
}
