﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleUI : MonoBehaviour {

    public CanvasGroup canvasGroup;
    public bool UIopen;

    public void toggleUI()
    {
        if (UIopen)
        {
            UIopen = false;
        }
        else if (!UIopen)
        {
            UIopen = true;
        }
    }

	// Use this for initialization
	void Start () {
       // UIopen = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (UIopen)
        {
            canvasGroup.alpha = 1f;
            canvasGroup.blocksRaycasts = true;
        }
        else
        {
            canvasGroup.alpha = 0f;
            canvasGroup.blocksRaycasts = false;
        }
	}
}
