﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement: MonoBehaviour
{
    private GameObject gameManager;

    private float moveSpeed;
    private float moveLimiter = 0.7f;
    private float horizontal;
    private float vertical;

    private bool isClick;
    private float attack_timer;
    public float attack_time;

    public Vector2 lastMove;
    private Vector2 attackFace;

    private Animator anim;
    private bool playerMoving;
    private Rigidbody2D body;
    public GameObject Weapon;

    
    public float knockbackSpeed;
    public float knockbackTime;
    private float knockbackTimer;
    private bool isKnockback;

    private float CurrSpeed;

    void Start()
    {
        gameManager = GameObject.Find("GameManager");
        moveSpeed = gameManager.GetComponent<GameManager>().playerSpeed;
        CurrSpeed = moveSpeed;
        Weapon.gameObject.SetActive(false);
        isClick = false;
        isKnockback = false;
        anim = GetComponent<Animator>();
        body = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        moveSpeed = gameManager.GetComponent<GameManager>().playerSpeed;
        CurrSpeed = moveSpeed;

        if (isClick)
        {
            attack_timer -= Time.deltaTime;

            if (attack_timer <= 0f)
            {
                cancelAttack();
            }
        }

        if (isClick)
        {
            anim.SetBool("isAttacking", true);
            Weapon.gameObject.SetActive(true);
        }

        if (isKnockback)
        {
            knockbackTimer -= Time.deltaTime;

            if (knockbackTimer <= 0f)
            {
                CurrSpeed = moveSpeed;
                isKnockback = false;
            }
        }

        playerMoving = false;

        if (!GetComponent<PlayerHealthManager>().isDead)
        {
            if (horizontal != 0 && vertical != 0)
            {
                playerMoving = true;
                body.velocity = new Vector2((horizontal * CurrSpeed) * moveLimiter * Time.deltaTime, (vertical * CurrSpeed) * moveLimiter * Time.deltaTime);
            }
            else if (horizontal != 0)
            {
                playerMoving = true;
                body.velocity = new Vector2(horizontal * CurrSpeed * Time.deltaTime, 0f);
            }
            else if (vertical != 0)
            {
                playerMoving = true;
                body.velocity = new Vector2(0f, vertical * CurrSpeed * Time.deltaTime);
            }
            else
            {
                body.velocity = new Vector2(0f, 0f);
            }
        }
        else
        {
            body.velocity = new Vector2(0f, 0f);
        }

        if (playerMoving)
        {
            lastMove = new Vector2(horizontal, vertical);
            if (isClick && lastMove != attackFace)
            cancelAttack();
        }


        anim.SetFloat("MoveX", horizontal);
        anim.SetFloat("MoveY", vertical);
        anim.SetBool("isMoving", playerMoving);
        anim.SetFloat("LastMoveX", lastMove.x);
        anim.SetFloat("LastMoveY", lastMove.y);
    }

    void cancelAttack()
    {
        isClick = false;
        Weapon.gameObject.SetActive(false);
        anim.SetBool("isAttacking", false);
    }

    public void KnockBack()
    {
        knockbackTimer = knockbackTime;
        CurrSpeed = -1 * knockbackSpeed;
        isKnockback = true;
    }

    void FixedUpdate()
    {
        if (!GetComponent<PlayerHealthManager>().isDead)
        {
            horizontal = Input.GetAxisRaw("Horizontal");
            vertical = Input.GetAxisRaw("Vertical");

            if (Input.GetMouseButtonDown(0) && !isClick)
            {
                isClick = true;
                attackFace = new Vector2(horizontal, vertical);
                attack_timer = attack_time;
            }
        }
    }
}
