﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewFloor : MonoBehaviour
{

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            GameObject.Find("GameManager").GetComponent<GameManager>().OnNewFloor();
            GameObject.Find("StoreScreen").GetComponent<ShopManager>().UIopen = false;
            GameObject.Find("MainCamera").GetComponent<CameraController>().SetGameBounds();
        }
    }
}
